-- ===== VOKTA Barbearia: banco de dados (cole tudo no SQL Editor do Supabase e clique em Run) =====
-- ANTES de rodar: troque SEU_EMAIL_AQUI (nas 2 linhas marcadas) pelo e-mail que vai usar para entrar no app do barbeiro.

create table if not exists agendamentos (
  id bigint generated always as identity primary key,
  criado timestamptz not null default now(),
  nome text not null check (char_length(nome) between 3 and 80),
  whatsapp text not null check (char_length(whatsapp) between 10 and 13),
  servicos jsonb not null,
  total numeric(10,2) not null check (total > 0 and total < 5000),
  barbeiro text not null,
  data date not null,
  hora time not null,
  status text not null default 'agendado' check (status in ('agendado','concluido','cancelado','faltou'))
);

-- impede dois clientes no mesmo horário com o mesmo barbeiro
create unique index if not exists agendamentos_horario_unico
  on agendamentos (barbeiro, data, hora) where status <> 'cancelado';

alter table agendamentos enable row level security;

-- cliente (site público) só pode CRIAR agendamento novo
create policy "cliente cria" on agendamentos for insert to anon
  with check (status = 'agendado' and data >= current_date);

-- só o barbeiro logado (e-mail autorizado) lê e altera
create policy "barbeiro le" on agendamentos for select to authenticated
  using ((auth.jwt() ->> 'email') in ('SEU_EMAIL_AQUI'));          -- << troque aqui
create policy "barbeiro altera" on agendamentos for update to authenticated
  using ((auth.jwt() ->> 'email') in ('SEU_EMAIL_AQUI'))           -- << troque aqui
  with check (true);

-- o site do cliente só descobre QUAIS horários estão ocupados (nunca nomes nem telefones)
create or replace function horarios_ocupados(p_barbeiro text, p_data date)
returns setof time language sql security definer set search_path = public as $$
  select hora from agendamentos where barbeiro = p_barbeiro and data = p_data and status <> 'cancelado'
$$;
grant execute on function horarios_ocupados(text, date) to anon, authenticated;
