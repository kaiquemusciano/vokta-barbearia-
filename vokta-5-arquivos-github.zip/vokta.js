// Camada de dados: usa o Supabase se estiver configurado; senão, guarda neste aparelho (modo demonstração).
(function(){
const C=window.VOKTA,S=C.supabase,REMOTE=!!(S.url&&S.key),LS="vokta_ag_v1",AK="vokta_auth";
const H={apikey:S.key,"Content-Type":"application/json"};if(S.key&&!S.key.startsWith("sb_"))H.Authorization="Bearer "+S.key;
let mem=[];
const ler=()=>{try{return JSON.parse(localStorage.getItem(LS))||[]}catch(e){return mem}};
const grava=a=>{mem=a;try{localStorage.setItem(LS,JSON.stringify(a))}catch(e){}};
const getA=()=>{try{return JSON.parse(localStorage.getItem(AK))}catch(e){return null}};
const setA=o=>{try{o?localStorage.setItem(AK,JSON.stringify(o)):localStorage.removeItem(AK)}catch(e){}};
const guarda=j=>setA({t:j.access_token,r:j.refresh_token,exp:Date.now()+j.expires_in*1000});
async function tok(){const a=getA();if(!a)return null;if(a.exp>Date.now()+6e4)return a.t;
 const r=await fetch(S.url+"/auth/v1/token?grant_type=refresh_token",{method:"POST",headers:{apikey:S.key,"Content-Type":"application/json"},body:JSON.stringify({refresh_token:a.r})});
 if(!r.ok){setA(null);return null}const j=await r.json();guarda(j);return j.access_token}
window.V={remoto:REMOTE,
 brl:v=>v.toLocaleString("pt-BR",{style:"currency",currency:"BRL"}),
 dk:d=>d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0"),
 horas(){const[a,b]=C.horario.inicio.split(":").map(Number),[c,d]=C.horario.fim.split(":").map(Number),o=[];
  for(let m=a*60+b;m<=c*60+d;m+=C.horario.passo)o.push(String(Math.floor(m/60)).padStart(2,"0")+":"+String(m%60).padStart(2,"0"));return o},
 async ocupados(barbeiro,data){
  if(REMOTE){const r=await fetch(S.url+"/rest/v1/rpc/horarios_ocupados",{method:"POST",headers:H,body:JSON.stringify({p_barbeiro:barbeiro,p_data:data})});
   if(!r.ok)throw new Error("rede");return(await r.json()).map(x=>String(x).slice(0,5))}
  return ler().filter(a=>a.barbeiro===barbeiro&&a.data===data&&a.status!=="cancelado").map(a=>a.hora)},
 async criar(a){
  const row={nome:a.nome,whatsapp:a.whatsapp,servicos:a.servicos,total:a.total,barbeiro:a.barbeiro,data:a.data,hora:a.hora,status:"agendado"};
  if(REMOTE){const r=await fetch(S.url+"/rest/v1/agendamentos",{method:"POST",headers:{...H,Prefer:"return=minimal"},body:JSON.stringify(row)});
   if(r.status===409)throw new Error("ocupado");if(!r.ok)throw new Error("erro");return}
  const l=ler();if(l.some(x=>x.barbeiro===row.barbeiro&&x.data===row.data&&x.hora===row.hora&&x.status!=="cancelado"))throw new Error("ocupado");
  row.id=Date.now();row.criado=new Date().toISOString();l.push(row);grava(l)},
 // ---- área do barbeiro ----
 auth:{
  async entrar(email,senha){const r=await fetch(S.url+"/auth/v1/token?grant_type=password",{method:"POST",headers:{apikey:S.key,"Content-Type":"application/json"},body:JSON.stringify({email,password:senha})});
   if(!r.ok)throw new Error("login");guarda(await r.json())},
  async logado(){return REMOTE?!!(await tok()):true},
  sair(){setA(null)}},
 async todos(desde){
  if(REMOTE){const t=await tok();if(!t)throw new Error("auth");
   const r=await fetch(S.url+"/rest/v1/agendamentos?select=*&data=gte."+desde+"&order=data.asc,hora.asc&limit=3000",{headers:{apikey:S.key,Authorization:"Bearer "+t}});
   if(r.status===401||r.status===403)throw new Error("auth");if(!r.ok)throw new Error("rede");return r.json()}
  return ler().filter(a=>a.data>=desde).sort((a,b)=>(a.data+a.hora).localeCompare(b.data+b.hora))},
 async status(id,st){
  if(REMOTE){const t=await tok();if(!t)throw new Error("auth");
   const r=await fetch(S.url+"/rest/v1/agendamentos?id=eq."+id,{method:"PATCH",headers:{apikey:S.key,Authorization:"Bearer "+t,"Content-Type":"application/json"},body:JSON.stringify({status:st})});
   if(!r.ok)throw new Error("rede");return}
  grava(ler().map(a=>a.id===id?{...a,status:st}:a))},
 exemplo(){const l=ler().filter(x=>!x.exemplo);let k=1;
  for(let i=-150;i<=10;i++){const d=new Date();d.setDate(d.getDate()+i);if(!C.horario.dias.includes(d.getDay()))continue;
   V.horas().sort(()=>Math.random()-.5).slice(0,2+Math.floor(Math.random()*6)).forEach(h=>{
    const b=C.barbeiros[Math.floor(Math.random()*C.barbeiros.length)].id,sv=C.servicos[Math.floor(Math.random()*C.servicos.length)],r=Math.random();
    if(l.some(x=>x.barbeiro===b&&x.data===V.dk(d)&&x.hora===h))return;
    l.push({id:Date.now()+k++,exemplo:true,nome:"Cliente exemplo "+k,whatsapp:"13999990000",servicos:[{id:sv.id,nome:sv.nome,preco:sv.preco}],total:sv.preco,barbeiro:b,data:V.dk(d),hora:h,status:i<0?(r<.82?"concluido":r<.92?"cancelado":"faltou"):"agendado"})})}
  grava(l)},
 limpaExemplo(){grava(ler().filter(x=>!x.exemplo))}
};})();
